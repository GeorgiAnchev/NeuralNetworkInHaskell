module SampleData where

import ImageLoader;
import Control.Monad;
import System.Directory;


tinyTrainDirectory = "C:/Users/Owner/Desktop/uni/FP/2020/haskell/project/CIFARsmallFlattened/train/"  

--getAllFiles :: FilePath -> IO [FilePath]
getAllFiles path = do
    allItems <- getDirectoryContents path
    let a = take 100 allItems
    let fullStrings = map (path++) a
    b <- mapM pixels fullStrings
    return b

    --filterM doesFileExist allItems
    --files
    --return $ map (path ++ ) allItems

trainData :: IO [[Double]]
trainData = getAllFiles tinyTrainDirectory

getAllFolders path = do
    contents <- getDirectoryContents path
    filterM doesDirectoryExist contents