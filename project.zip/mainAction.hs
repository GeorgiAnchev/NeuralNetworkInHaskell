import TwoLayerNet;
import RandomProvider;
import MathOperations;
import SampleData;


inputSize = 32 * 32 * 3;
hiddenSize = 50;
numClasses = 10;
numInputs = 100;

--std = 1e-1;

randomWeights = getRandomWeights inputSize hiddenSize numClasses;

--toyX = getRandomMatrix numInputs inputSize `multMatByScalar` (10::Double);

trainY :: [Int]
trainY = concat $ map (\i -> replicate 10 i ) [0..9] ;   --[0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,2,2,2,2,, ... ,8,8,9,9,9,9,9,9,9,9,9,]

sampleReg :: Double
sampleReg = 0.05

iterations :: Int
iterations = 100

trainTheNN :: IO NNParams
trainTheNN = do
    trainX <- trainData
    print "dataLoaded"
    let trainedWeights = train randomWeights trainX trainY (1e-1) 0.95 (5e-6) iterations 
    return trainedWeights

fakeX :: [[Double]]
fakeX = [[]]

-- we get loss of 2656.792170588558 for untrained weights
lossUntrained :: IO Double  
lossUntrained = do
    trainX <- trainData
    print "dataLoaded"
    let calculatedLoss = loss randomWeights trainX trainY sampleReg
    return calculatedLoss

-- with 30 iterations we get loss of 2571.3904234861616 
lossTrained :: IO Double
lossTrained = do
    trainX <- trainData
    print "dataLoaded"
    trainedWeights <- trainTheNN
    let calculatedLoss = loss trainedWeights trainX trainY sampleReg
    return calculatedLoss

--toyPrediction = predict neuralNet fakeX 

--toyAccuracy = getAccuracy toyPrediction toyY